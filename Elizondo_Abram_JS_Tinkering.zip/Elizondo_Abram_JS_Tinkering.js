var childHeight = 4;
function IfChildIsAbleToRideTheRollerCoasetInterval()
{if (childHeight > 54){
    console.log("Get on that ride, kiddo!") 
}else{
      console.log("Sorry kiddo. Maybe next year.")}
    
}